package com.ly.bigdata;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@SpringBootTest
class SpringbootPersonManagerApplicationTests {


    @Autowired
    private JavaMailSender mailSender;

    @Test
    void contextLoads() {

        //System.out.println(DigestUtils.md5DigestAsHex("admin123".getBytes()));
        SimpleMailMessage mailMessage=new SimpleMailMessage();
        mailMessage.setSubject("用户注册");
        mailMessage.setText("用户张三注册了一个账号，请管理员审核！");
        mailMessage.setFrom("qzhangsq@126.com");
        mailMessage.setTo("87704991@qq.com","3136667558@qq.com","ruiqi_920251764@163.com"
        ,"xdybsan@gmail.com");

        mailSender.send(mailMessage);

    }


    @Test
    public void getUserInfo(){

    }

}
