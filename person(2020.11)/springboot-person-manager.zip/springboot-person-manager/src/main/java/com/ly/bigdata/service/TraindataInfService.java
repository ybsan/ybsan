package com.ly.bigdata.service;

import com.ly.bigdata.po.TraindataInf;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-29
 */
public interface TraindataInfService extends IService<TraindataInf> {

}
