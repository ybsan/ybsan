package com.ly.bigdata.controller;

import com.ly.bigdata.service.SendMailService;
import com.ly.bigdata.utils.MailUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.channels.MulticastChannel;

@RestController
public class TestSendMailController {


    @Autowired
    private SendMailService sendMailService;

    @RequestMapping("/send")
    public String sendMail(){
       // String[] to={"87704991@qq.com"};
       // MailUtils.sendMail(javaMailSender,"注册用户1","请审核","qzhangsq@126.com",to);

        return "send mail ok";
    }


    @RequestMapping("/send2")
    public String send(){
        String[] to={"87704991@qq.com"};
        sendMailService.send("注册用户1","请审核","qzhangsq@126.com",to);
        return "send mail ok2";
    }


}
