package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ly.bigdata.po.StatusInf;
import com.ly.bigdata.po.UserInf;
import com.ly.bigdata.po.UservisitInf;
import com.ly.bigdata.service.StatusInfService;
import com.ly.bigdata.service.UserInfService;
import com.ly.bigdata.service.UservisitInfService;
import eu.bitwalker.useragentutils.Browser;
import eu.bitwalker.useragentutils.OperatingSystem;
import eu.bitwalker.useragentutils.UserAgent;
import eu.bitwalker.useragentutils.Version;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-22
 */
@Controller
@RequestMapping("/user")
public class UserInfController {

    @Autowired
    private UserInfService userInfService;

    @Autowired
    private StatusInfService statusInfService;

    @Autowired
    private UservisitInfService uservisitInfService;

    @Autowired
    private StringRedisTemplate redisTemplate;

    @RequestMapping("/list")
    public String toList(@RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
                         @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
                         @RequestParam(value = "content", required = false) String content,
                         Model model) {

      Page<UserInf> page = new Page<>(pageNo, pageSize);
        if (content != null && !content.equals("")) {
            QueryWrapper<UserInf> wrapper = new QueryWrapper<>();
            wrapper.like("loginname", content)
                    .or().like("username", content);
            userInfService.page(page, wrapper);
        } else {
            userInfService.page(page, null);
        }



       model.addAttribute("list", page.getRecords());
        model.addAttribute("pageNo", page.getCurrent());
        model.addAttribute("pageSize", page.getSize());
        model.addAttribute("count", page.getTotal());
        /*System.out.println("当前页："+page.getCurrent());
        System.out.println("每页记录数："+page.getSize());
        System.out.println("总录数："+page.getTotal());
        System.out.println("总页数："+page.getPages());
        System.out.println("上一页："+(page.hasPrevious()?page.getCurrent()-1:1));
        System.out.println("下一页："+(page.hasNext()?page.getCurrent()+1:page.getPages()));*/

        return "user/list";
    }

    @RequestMapping("/toadd")
    public String toAdd() {
        return "user/add";
    }

    @RequestMapping("/add")
    public String addUser(UserInf userInf) {
        userInf.setStatusId(0);
        userInf.setCreatedate(new Date());
        System.out.println(userInf);
        // md5加密
        String pwd = DigestUtils.md5DigestAsHex(userInf.getPassword().getBytes());
        userInf.setPassword(pwd);
        userInfService.save(userInf);

        return "redirect:/user/list";
    }

    @RequestMapping("/toedit")
    public String getUser(Integer id, Model model) {
        UserInf userInf = userInfService.getById(id);
        List<StatusInf> list = statusInfService.list(null);
        System.out.println(userInf);
        System.out.println("---------------------------------");
        model.addAttribute("user", userInf);
        model.addAttribute("list", list);
        return "user/edit";
    }

    @RequestMapping("/edit")
    public String editUser(UserInf userInf) {
        System.out.println(userInf);
        userInfService.saveOrUpdate(userInf);
        return "redirect:/user/list";
    }

    @RequestMapping("/delete")
    public String delUser(Integer id) {
        userInfService.removeById(id);
        return "redirect:/user/list";
    }

    @RequestMapping("/topedit")
    public String getUserById(Integer id, Model model) {
        UserInf userInf = userInfService.getById(id);
        model.addAttribute("user", userInf);
        return "user/pedit";
    }

    @RequestMapping("/pedit")
    public String peditUser(UserInf userInf) {
        System.out.println(userInf);
        userInfService.saveOrUpdate(userInf);
        return "redirect:/user/list";
    }

    @RequestMapping("/login")
    public String login(String loginname, String password, String user_input_verifyCode,
                        HttpSession session, Model model,HttpServletRequest request) {
        this.getClientInfo(request,loginname);
        try {
            String sessionCode = (String) session.getAttribute("code");
            if (sessionCode.equalsIgnoreCase(sessionCode)) {
                QueryWrapper<UserInf> wrapper = new QueryWrapper<>();
                String pwd = DigestUtils.md5DigestAsHex(password.getBytes());
                wrapper.eq("loginname", loginname).eq("password", pwd);
                UserInf userInf = userInfService.getOne(wrapper);
                if (userInf != null) {
                    if (userInf.getStatusId() == 1) {
                        // session 放置当前用户
                        session.setAttribute("user_session", userInf);
                        return "index";
                    } else {
                        model.addAttribute("message", "等待管理员审核！");
                        return "loginForm";
                    }
                } else {
                    model.addAttribute("message", "用户名或密码不正确！");
                    return "loginForm";
                }
            } else {
                model.addAttribute("message", "验证码不正确！");
                return "loginForm";
            }
        } catch (Exception e) {
            return "redirect:/";
        }
    }



    public  void getClientInfo(HttpServletRequest request,String loginname){
        String agent =request.getHeader("User-Agent");
        System.out.println(agent);

        //User Agent中文名为用户代理，简称 UA，它是一个特殊字符串头，使得服务器
        //能够识别客户使用的操作系统及版本、CPU 类型、浏览器及版本、
        //浏览器渲染引擎、浏览器语言、浏览器插件等
        UserAgent userAgent = UserAgent.parseUserAgentString(agent);

        // 获取浏览器
        Browser browser = userAgent.getBrowser();
        //System.out.println(browser.getName());
        // 获取浏览器版本
        Version bv = userAgent.getBrowserVersion();
        //System.out.println(bv.getVersion());
        // 获取操作系统
        OperatingSystem os = userAgent.getOperatingSystem();
        //System.out.println(os.getName());

        String iphone = "";
        if (agent.contains("Windows NT")) {
            //pc型号获取方法实现
            String pc_regex = " \\((.*); ";
            Pattern pattern = Pattern.compile(pc_regex);
            Matcher matcher = pattern.matcher(agent);
            while (matcher.find()) {
                iphone = matcher.group(1);
            }
            agent = "PC端";
        } else {
           String type = "";
            if (agent.contains("iPhone") || agent.contains("iPod") || agent.contains("iPad")) {
                type = "ios";
            } else if (agent.contains("Android") || agent.contains("Linux")) {
                type = "apk";
            } else if (agent.indexOf("micromessenger") > 0) {
                type = "wx";
            }
            String iphone_regex = "\\((.*)\\) Apple";
            Pattern pattern = Pattern.compile(iphone_regex);
            Matcher matcher = pattern.matcher(agent);

            while (matcher.find()) {
                iphone = matcher.group(1);
            }
            agent = "移动端" + type;
        }

        System.out.println(iphone);
        System.out.println(agent);

        System.out.println("---------------------获取ip--------------------------");
        String ipAddress = null;
        if (request.getHeader("x-forwarded-for") == null) {
            ipAddress = request.getRemoteAddr();
        } else {
            if (request.getHeader("x-forwarded-for").length() > 15) {
                String[] aStr = request.getHeader("x-forwarded-for").split(",");
                ipAddress = aStr[0];
            } else {
                ipAddress = request.getHeader("x-forwarded-for");
            }
        }
        System.out.println(ipAddress);

        // 封装UservisitInf
        UservisitInf uservisitInf =new UservisitInf();
        uservisitInf.setLoginname(loginname);
        uservisitInf.setLoginTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        uservisitInf.setVisitIp(ipAddress);
        uservisitInf.setUserAddress("");
        uservisitInf.setUserFrom(agent);
        uservisitInf.setBrowser(browser.getName());
        uservisitInf.setOpsystem(os.getName());
        uservisitInf.setVersion(bv.getVersion());
        uservisitInf.setIphone(iphone);

        // 写入数据库
        uservisitInfService.save(uservisitInf);
        String s = null;
        try {
            s = new ObjectMapper().writeValueAsString(uservisitInf);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        // 写入redis
        redisTemplate.opsForList().leftPush("users",s);
        // 写入到session
        request.getSession().setAttribute("USERV_ISIT",uservisitInf);

    }




}

