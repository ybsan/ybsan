package com.ly.bigdata.mapper;

import com.ly.bigdata.po.LeavestatusInf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-26
 */
public interface LeavestatusInfMapper extends BaseMapper<LeavestatusInf> {

}
