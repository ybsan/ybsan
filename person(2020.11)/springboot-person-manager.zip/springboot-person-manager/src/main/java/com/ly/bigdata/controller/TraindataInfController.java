package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bigdata.po.TraindataInf;
import com.ly.bigdata.po.UserInf;
import com.ly.bigdata.service.TraindataInfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-29
 */
@Controller
@RequestMapping("/traindata")
public class TraindataInfController {

    @Autowired
    private TraindataInfService traindataInfService;

    @RequestMapping("/list")
    public String toList(@RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
                         @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
                         @RequestParam(value = "content", required = false) String content,
                         Model model) {
        Page<TraindataInf> page = new Page<>(pageNo, pageSize);
        if (content != null && !content.equals("")) {
            QueryWrapper<TraindataInf> wrapper = new QueryWrapper<>();
            wrapper.like("title", content )
                    .or().like("filename", content)
                    .or().like("remark", content);
            traindataInfService.page(page, wrapper);
        } else {
            traindataInfService.page(page, null);
        }


        model.addAttribute("list", page.getRecords());
        model.addAttribute("pageNo", page.getCurrent());
        model.addAttribute("pageSize", page.getSize());
        model.addAttribute("count", page.getTotal());

        return "traindata/list";
    }


    @RequestMapping("/play")
    public String play(String filename,Model model){
        System.out.println(filename);
        model.addAttribute("filename",filename);
        return "traindata/play";
    }

}

