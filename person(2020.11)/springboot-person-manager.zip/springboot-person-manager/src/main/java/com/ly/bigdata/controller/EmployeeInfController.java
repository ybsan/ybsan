package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bigdata.po.*;
import com.ly.bigdata.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-25
 */
@Controller
@RequestMapping("/employee")
public class EmployeeInfController {
    @Autowired
    private EmployeeInfService employeeInfService;

    @Autowired
    private UserInfService userInfService;

    @Autowired
    private SexInfService sexInfService;

    @Autowired
    private EducationInfService educationInfService;

    @Autowired
    private DeptInfService deptInfService;

    @Autowired
    private JobInfService jobInfService;

    @RequestMapping("/list")
    public String toList(@RequestParam(value = "pageNo", defaultValue = "1") Integer pageNo,
                         @RequestParam(value = "pageSize", defaultValue = "5") Integer pageSize,
                         @RequestParam(value = "content", required = false) String content,
                         Model model) {
        Page<EmployeeInf> page = new Page<>(pageNo, pageSize);
        employeeInfService.selectEmpAll(page, content);

        model.addAttribute("list", page.getRecords());
        model.addAttribute("pageNo", page.getCurrent());
        model.addAttribute("pageSize", page.getSize());
        model.addAttribute("count", page.getTotal());


        return "employee/list";
    }


    @RequestMapping("/association")
    public String toAdd() {
        return "/employee/association";
    }

    @RequestMapping("/toassociation")
    public String toassociation(String loginname, Model model) {
        QueryWrapper<UserInf> wrapper = new QueryWrapper<>();
        wrapper.eq("loginname", loginname);
        UserInf userInf = userInfService.getOne(wrapper);
        if (userInf != null) {
            List<SexInf> sex_list = sexInfService.list(null);
            List<DeptInf> dept_list = deptInfService.list(null);
            List<EducationInf> education_list = educationInfService.list(null);
            List<JobInf> job_list = jobInfService.list(null);
            model.addAttribute("sex_list", sex_list);
            model.addAttribute("dept_list", dept_list);
            model.addAttribute("education_list", education_list);
            model.addAttribute("job_list", job_list);
            model.addAttribute("user", userInf);
            return "/employee/add";
        } else {
            model.addAttribute("message", "此用户不存在,请修改");
            return "/employee/association";
        }
    }

    @RequestMapping("/delete")
    public void delEmp(Integer id) {
        employeeInfService.removeById(id);
    }


    @RequestMapping("/toedit")
    public String toedit(Integer id, Model model) {
        EmployeeInf employeeInf = employeeInfService.getById(id);
        List<SexInf> sex_list = sexInfService.list(null);
        List<DeptInf> dept_list = deptInfService.list(null);
        List<EducationInf> education_list = educationInfService.list(null);
        List<JobInf> job_list = jobInfService.list(null);
        model.addAttribute("employee", employeeInf);
        model.addAttribute("sex_list", sex_list);
        model.addAttribute("dept_list", dept_list);
        model.addAttribute("education_list", education_list);
        model.addAttribute("job_list", job_list);
        return "employee/edit";
    }

    @RequestMapping("/add")
    public String addEmp(EmployeeInf employeeInf){
        // 创建时间
        employeeInf.setCreatedate(new Date());
        System.out.println(employeeInf);
        employeeInfService.save(employeeInf);
        return "redirect:/employee/list";
    }



    @RequestMapping("/edit")
    public String editEmp(EmployeeInf employeeInf){
        System.out.println(employeeInf);
        employeeInfService.updateById(employeeInf);
        return "redirect:/employee/list";
    }


}

