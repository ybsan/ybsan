package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bigdata.po.DeptInf;
import com.ly.bigdata.service.DeptInfService;
import com.ly.bigdata.vo.DeptNum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author qzhang
 * @since 2021-03-19
 */
@Controller
@RequestMapping("/dept")
public class DeptInfController {

    @Autowired
    private DeptInfService deptInfService;

    @RequestMapping("/list")
    public String getList(@RequestParam(value = "content", required = false) String content, Model model) {
        List<DeptInf> list = null;
        if (content != null && !"".equals(content)) {
            QueryWrapper<DeptInf> wrapper = new QueryWrapper<>();
            wrapper.like("name", content)
                    .or().like("remark", content);
            list = deptInfService.list(wrapper);
        } else {
            list = deptInfService.list(null);
        }

        model.addAttribute("list", list);
        return "/dept/list";
    }

    @RequestMapping("/toadd")
    public String toAdd() {
        return "/dept/add";
    }

    @RequestMapping("/add")
    public String addDept(DeptInf dept) {
        System.out.print(dept);
        deptInfService.save(dept);
        return "redirect:/dept/list";
    }

    @RequestMapping("/toedit")
    public String toEdit(Integer id, Model model) {
        DeptInf dept = deptInfService.getById(id);
        model.addAttribute("dept", dept);
        return "/dept/edit";
    }

    @RequestMapping("/edit")
    public String editDept(DeptInf dept) {
        deptInfService.saveOrUpdate(dept);
        return "redirect:/dept/list";
    }

    @RequestMapping("/delete")
    public void delDept(Integer id) {
        deptInfService.removeById(id);
    }


    @RequestMapping("/getDeptNum")
    @ResponseBody
    public Object getDeptNum() {
        List<DeptNum> list =deptInfService.getDeptNumbers();
        list.forEach(d-> System.out.println(d));
        return list;
    }

}

