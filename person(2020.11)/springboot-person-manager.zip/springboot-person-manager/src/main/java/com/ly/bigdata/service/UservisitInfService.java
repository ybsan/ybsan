package com.ly.bigdata.service;

import com.ly.bigdata.po.UservisitInf;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author qzhang
 * @since 2021-03-20
 */
public interface UservisitInfService extends IService<UservisitInf> {

}
