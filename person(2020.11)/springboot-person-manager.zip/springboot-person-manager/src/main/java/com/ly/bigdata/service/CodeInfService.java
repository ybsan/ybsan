package com.ly.bigdata.service;

import com.ly.bigdata.po.CodeInf;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-23
 */
public interface CodeInfService extends IService<CodeInf> {

}
