package com.ly.bigdata.controller;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.ly.bigdata.po.CodeInf;
import com.ly.bigdata.po.UserInf;
import com.ly.bigdata.service.CodeInfService;
import com.ly.bigdata.service.SendMailService;
import com.ly.bigdata.service.UserInfService;
import com.ly.bigdata.utils.GenCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.Date;

@Controller
public class RegisterCheckController {


    @Autowired
    private CodeInfService codeInfService;
    @Autowired
    private UserInfService userInfService;

    @Autowired
    private SendMailService mailService;


    @RequestMapping("/registCode")
    public String registCode() {
        return "registCode";
    }

    @RequestMapping("/toregist")
    public String toregist() {
        return "regist";
    }

    @RequestMapping("/toCreateCode")
    @ResponseBody
    public Object toCreateCode() {
        String code = GenCode.gen();
        CodeInf codeInf = new CodeInf();
        codeInf.setCode(code);
        codeInfService.save(codeInf);
        return codeInf;
    }

    @RequestMapping("/toregistCode")
    @ResponseBody
    public Object toregistCode(String registCode) {
        CodeInf codeInf = codeInfService.getOne(new QueryWrapper<CodeInf>().eq("code", registCode));
        if (codeInf != null) {
            return "";
        } else {
            return "验证不正确,请重新输入！";
        }
    }


    @RequestMapping("/check_Register_loginname")
    @ResponseBody
    public String check_Register_loginname(String loginname) {
        QueryWrapper<UserInf> wrapper = new QueryWrapper<UserInf>();
        wrapper.eq("loginname", loginname);
        UserInf userInf = userInfService.getOne(wrapper);
        if (userInf != null) {
            return "用登录名已存在，请更换！";
        } else {
            return "";
        }
    }

    @RequestMapping("/check_Register_email")
    @ResponseBody
    public String check_Register_email(String email) {
        QueryWrapper<UserInf> wrapper = new QueryWrapper<UserInf>();
        wrapper.eq("email", email);
        UserInf userInf = userInfService.getOne(wrapper);
        if (userInf != null) {
            return "邮箱已存在，请更换！";
        } else {
            return "";
        }
    }

    @RequestMapping("/register")
    public String addUser(UserInf userInf) {

        userInf.setStatusId(0);
        userInf.setCreatedate(new Date());
        System.out.println(userInf);
        // md5加密
        String pwd = DigestUtils.md5DigestAsHex(userInf.getPassword().getBytes());
        userInf.setPassword(pwd);
        userInfService.save(userInf);
        // 发送邮件给管理员
        mailService.send("用户注册","用户注册，请管理员审批！","qzhangsq@126.com",new String[]{"87704991@qq.com"});
        return "loginForm";
    }

    @RequestMapping("/repassword")
    public String toRepassWord() {
        return "repasswordPage";
    }

    @RequestMapping("/toFindPassword")
    public String toFindPassword(UserInf userInf, String user_input_verifyCode, HttpSession httpSession, Model model
    ) {

        String code = (String) httpSession.getAttribute("code");
        if (code.equalsIgnoreCase(user_input_verifyCode)) {
            QueryWrapper<UserInf> wrapper = new QueryWrapper<>();
            wrapper.eq("loginname", userInf.getLoginname())
                    .eq("username", userInf.getUsername());
            UserInf dbUser = userInfService.getOne(wrapper);
            if (dbUser != null) {
                model.addAttribute("user", dbUser);
                return "findPassword";
            } else {
                model.addAttribute("message", "账号或用户名不正确");
                return "repasswordPage";
            }
        } else {
            model.addAttribute("message", "验证码不正确");
            return "repasswordPage";
        }
    }

    @RequestMapping("/rePassword")
    public String rePassword(UserInf userInf){
        String pwd=DigestUtils.md5DigestAsHex(userInf.getPassword().getBytes());
        userInf.setPassword(pwd);
        userInfService.updateById(userInf);
        return "redirect:/";
    }
}
