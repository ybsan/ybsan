package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bigdata.po.JobInf;
import com.ly.bigdata.service.JobInfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-25
 */
@Controller
@RequestMapping("/job")
public class JobInfController {
    @Autowired
    private JobInfService jobInfService;

    @RequestMapping("/list")
    public String getList(@RequestParam(value = "content", required = false) String content, Model model) {
        List<JobInf> list =null;
        if(content!=null&&!"".equals(content)){
            QueryWrapper<JobInf> wrapper=new QueryWrapper<>();
            wrapper.like("name", "%" + content + "%")
                    .or().like("remark", "%" + content + "%");
            list =jobInfService.list(wrapper);
        }else{
            list =jobInfService.list(null);
        }
        model.addAttribute("list", list);
        return "/job/list";
    }

    @RequestMapping("/toadd")
    public String toAdd() {
        return "/job/add";
    }

    @RequestMapping("/toedit")
    public String toEdit(Integer id, Model model) {
        JobInf job =jobInfService.getById(id);
        model.addAttribute("job", job);
        return "/job/edit";
    }

    @RequestMapping("/add")
    public String addJob(JobInf job) {
        jobInfService.save(job);
        return "redirect:/job/list";
    }

    @RequestMapping("/edit")
    public String editJob(JobInf job) {
        jobInfService.saveOrUpdate(job);
        return "redirect:/job/list";
    }


    @RequestMapping("/delete")
    public void delJob(Integer id) {
        jobInfService.removeById(id);
    }
}

