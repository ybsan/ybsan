package com.ly.bigdata.mapper;

import com.ly.bigdata.po.UservisitInf;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author qzhang
 * @since 2021-03-20
 */
public interface UservisitInfMapper extends BaseMapper<UservisitInf> {

}
