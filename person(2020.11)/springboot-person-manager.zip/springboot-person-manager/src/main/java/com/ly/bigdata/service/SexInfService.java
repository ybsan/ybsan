package com.ly.bigdata.service;

import com.ly.bigdata.po.SexInf;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-25
 */
public interface SexInfService extends IService<SexInf> {

}
