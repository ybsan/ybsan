package com.ly.bigdata.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StatisticsController {

    @RequestMapping("/statistics")
    public String toStatistics() {
        return "statistics/statistics";
    }


    @RequestMapping("/echart")
    public String toEchart() {
        return "statistics/echart";
    }

    @RequestMapping("/echart2")
    public String toEchart2() {
        return "statistics/echart2";
    }

    @RequestMapping("/echart3")
    public String toEchart3() {
        return "statistics/echart3";
    }

    @RequestMapping("/echart4")
    public String toEchart4() {
        return "statistics/echart4";
    }
}
