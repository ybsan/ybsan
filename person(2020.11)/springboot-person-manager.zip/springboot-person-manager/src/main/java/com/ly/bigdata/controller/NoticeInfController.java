package com.ly.bigdata.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.ly.bigdata.po.NoticeInf;
import com.ly.bigdata.service.NoticeInfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author qzhangsq
 * @since 2021-03-26
 */
@Controller
@RequestMapping("/notice")
public class NoticeInfController {
    @Autowired
    private NoticeInfService noticeInfService;

    //pageIndex当前是第几页
    @RequestMapping("/list")
    public String getList(@RequestParam(value = "page", defaultValue = "1") Integer page,
                          @RequestParam(value = "limit", defaultValue = "10") Integer limit,
                          Model model) {

        Page<NoticeInf> pager = new Page<>(page, limit);
        //1.然后跳转到list的页面 进行显示  2.要带上公告的信息  进行数据库的查询
        noticeInfService.page(pager, null);
        model.addAttribute("list", pager.getRecords());
        model.addAttribute("total", pager.getTotal());
        model.addAttribute("curr", pager.getCurrent());
        return "notice/list";
    }

    // 添加的页面
    @RequestMapping("/toadd")
    public String toAdd() {
        return "notice/add";
    }
}

