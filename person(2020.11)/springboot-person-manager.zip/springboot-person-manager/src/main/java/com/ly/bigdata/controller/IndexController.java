package com.ly.bigdata.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ly.bigdata.po.CodeInf;
import com.ly.bigdata.po.UservisitInf;
import com.ly.bigdata.service.CodeInfService;
import com.ly.bigdata.service.UservisitInfService;
import com.ly.bigdata.utils.GenCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
public class IndexController {

    @Autowired
    private UservisitInfService uservisitInfService;

    @RequestMapping("/")
    public String toLogin(){
        return "loginForm";
    }

    @RequestMapping("/index")
    public String toIndex(){
        return "index";
    }


    @RequestMapping("/welcome")
    public String welcome(){
        return "welcome";
    }

    @RequestMapping("/exit")
    public String logout(HttpSession session){
        // 获取UserVisitInf
        UservisitInf uservisitInf = (UservisitInf) session.getAttribute("USERV_ISIT");
        if(uservisitInf!=null){
            uservisitInf.setExitTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            uservisitInfService.updateById(uservisitInf);
        }
        session.invalidate();
        return "loginForm";
    }




}
